from netmanage import *
from . import netui
__title__ = 'netui-gtk'
__version__ = '0.0.1'
__author__ = 'Samy Abdellatif'
__license__ = 'MIT'
__docformat__ = 'restructuredtext en'